const config = {
    development: {
        frontendUrl: 'http://localhost:5500',
        serverUrl: 'http://localhost:3000',
        corsOrigins: ['http://localhost:5500', 'http://127.0.0.1:5500']
    },
    production: {
        frontendUrl: 'https://yourusername.github.io/yourrepo',
        serverUrl: 'https://your-azure-app.azurewebsites.net',
        corsOrigins: ['https://yourusername.github.io']
    }
};

const environment = process.env.NODE_ENV || 'development';
module.exports = config[environment];
